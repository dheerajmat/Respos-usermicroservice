import * as categoryService from '../services/categoryService.js';
import logger from '../utils/logger.js';


const getCategoryToCreateModal = async (req, res, next) => {
    try {
        const categories = await categoryService.getCategoryToCreateModal();
        res.status(200).json(categories);
    } catch (error) {
        logger.error('Error getting category to create modal', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const searchCategories = async (req, res, next) => {
    try {
        const { catname, ispublished, page = 1, limit = 10 } = req.body;

        const filterParams = {
            catname,
            ispublished: ispublished === 'true' ? true : ispublished === 'false' ? false : undefined,
            page: parseInt(page),
            limit: parseInt(limit)
        }

        const result = await categoryService.searchCategories(filterParams);

        res.status(200).json({
            result: result.categories,
            pagination: {
                totalItems: result.totalCount,
                currentPage: result.currentPage,
                totalPages: result.totalPages,
                itemsPerPage: filterParams.limit
            }
        });
    } catch (error) {
        logger.error('Error searching categories', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const createCategory = async (req, res, next) => {
    try {
        const category = await categoryService.createCategory(req.body, req.user.uid);
        res.status(201).json(category);
    } catch (error) {
        logger.error('Error creating category', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const getCategories = async (req, res, next) => {
    try {
        const categories = await categoryService.getCategories();
        res.status(200).json(categories);
    } catch (error) {
        logger.error('Error getting categories', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const getCategoryById = async (req, res, next) => {
    try {
        const category = await categoryService.getCategoryById(req.params.id);
        if (!category) return res.status(400).json({ message: `Category not found for ID ${req.params.id}` });
        res.status(200).json(category);
    } catch (error) {
        logger.error('Error getting category by id', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const updateCategory = async (req, res, next) => {
    try {
        const updatedCategory = await categoryService.updateCategory(req.params.id, req.body, req.user.uid);
        res.status(200).json(updatedCategory);
    } catch (error) {
        logger.error('Error updating category', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const deleteCategory = async (req, res, next) => {
    try {
        await categoryService.deleteCategory(req.params.id, req.user.uid);
        res.status(200).json({ message: "Category successfully deleted" });
    } catch (error) {
        logger.error('Error deleting category', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

// const getCategoriesByFilter = async (req, res, next) => {
//     try {
//         const {catname, ispublished}
//         const categories = await categoryService.getCategoriesByFilter()
//     } catch (error) {
        
//     }
// }

export {
    getCategoryToCreateModal,
    searchCategories,
    createCategory,
    getCategories,
    getCategoryById,
    updateCategory,
    deleteCategory
};