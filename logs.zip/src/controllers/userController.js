import * as userService from '../services/userService.js';
import { AppError } from '../middleware/errorHandler.js';
import { serializeData } from '../utils/serializer.js';
import logger from '../utils/logger.js';

const addUser = async (req, res, next) => {
    try {
        if (!req.body.emailid || !req.body.password) {
            return next(new AppError('Please provide email and password!', 400));
        }

        const userData = await userService.addUser(req.body);

        res.status(201).json(userData);
    } catch (error) {
        logger.warn('Error adding user', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
};

// const addUser = async (req, res, next) => {
//     try {
//         if (!req.body.emailid || !req.body.password) {
//             throw new AppError('Please provide email and password!', 400);
//         }

//         const userData = await userService.addUser(req.body);

//         // Remove sensitive data before sending response
//         const { password, ...userResponse } = userData;

//         res.status(201).json(userResponse);
//     } catch (error) {
//         logger.error('Error adding user', {
//             error: error.message,
//             stack: error.stack
//         });
//         next(error);
//     }
// };

const getUserById = async (req, res, next) => {
    try {
        const user = await userService.getUserById(req.params.id);
        if (!user) {
            return next(new AppError('User not found', 404));
        }

        res.status(200).json(user);
    } catch (error) {
        logger.warn('Error adding user', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const getsaveusermodal = async (req, res, next) => {
    const ROLES = {
        // SUPER_ADMIN: 1,
        OUTLET_MANAGER: 2,
        WAITER: 3,
        KITCHEN_MANAGER: 4,
        INVENTORY_MANAGER: 5
    };

    const roleDropdown = [
        // { id: ROLES.SUPER_ADMIN, name: "Super Admin" },
        { id: ROLES.OUTLET_MANAGER, name: "Outlet Manager" },
        { id: ROLES.WAITER, name: "Waiter" },
        { id: ROLES.KITCHEN_MANAGER, name: "Kitchen Manager" },
        { id: ROLES.INVENTORY_MANAGER, name: "Inventory Manager" }
    ];

    try {
        const userModalData = {
            fullname: "",
            firstname: "",
            lastname: "",
            emailid: "",
            mobno: "",
            employeeid: "",
            canlogin: true,
            password: "",
            usercode: "",
            image: "",
            profilestatus: 0,
            isapproved: true,
            accountstatus: 0,
            roleid: 0,
            roleName: "",
            roleModels: [
                {
                    uoid: 0,
                    roleid: 0,
                    roletypeid: 0
                }
            ],
            // rightsOfUserModel: {
            //   modules: [
            //     {
            //       moduleName: "",
            //       rightsList: [
            //         {
            //           rightId: 0,
            //           rightName: "",
            //           selected: true
            //         }
            //       ]
            //     }
            //   ]
            // }
        };

        // Send userModalData along with roles dropdown
        res.status(200).json({
            userModalData,
            roles: roleDropdown
        });
    } catch (error) {
        logger.warn('Error getting save user modal data', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const editUser = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const modifiedby = req.user.uid;
        const userData = req.body;

        // Validate required fields
        if (!userId) {
            throw new AppError('User ID is required', 400);
        }

        const updatedUser = await userService.editUser(userId, userData, modifiedby);

        // Get additional data
        const [roles, rights] = await Promise.all([
            userService.getUserRoles(userId),
            userService.getUserRights(userId)
        ]);

        // Combine and serialize the response data
        const responseData = {
            ...updatedUser,
            role_mappings: roles,
            rights_mappings: rights
        };

        logger.info('User updated successfully', { userId });

        res.status(200).json(responseData);

    } catch (error) {
        logger.error('Error in updateUser controller', {
            error: error.message,
            stack: error.stack,
            userId: req.params.id
        });
        next(error);
    }
};

const getAllUsers = async (req, res, next) => {
    try {
        const users = await userService.getAllUsers(req.user.uoid);
        res.status(200).json(users)
    } catch (error) {
        logger.error('Error fetching all users', {
            error: error.message,
            stack: error.stack
        });
        next(error);
    }
}

const userSearch = async (req, res, next) => {
    try {
        const uoid = req.user.uoid;

        // Validate and sanitize pagination parameters
        const pagination = {
            itemsPerPage: parseInt(req.body.pagination?.itemPerPage) || 10,
            currentPage: parseInt(req.body.pagination?.currentPage) || 1
        };

        // Validate and sanitize search terms
        const searchTerms = {
            name: req.body.name || '',
            status: req.body.status || '',
            role: req.body.role || null,
            uoid
        };

        const results = await userService.userSearch(searchTerms, pagination);

        res.status(200).json({
            success: true,
            data: serializeData(results)
        });
    } catch (error) {
        logger.error('Error in user search:', {
            error: error.message,
            stack: error.stack,
            body: req.body
        });
        next(error);
    }
}

const deleteUser = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const deletedby = req.user.uid;
        await userService.deleteUser(userId, deletedby);
        res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
        logger.error('Error deleting user', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const updateProfileStatus = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const { profileStatus } = req.body;
        const updatedUser = await userService.updateProfileStatus(userId, profileStatus);
        res.status(200).json(updatedUser);
    } catch (error) {
        logger.error('Error updating profile status', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const updateAccountStatus = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const { accountStatus } = req.body;
        const updatedUser = await userService.updateAccountStatus(userId, accountStatus);
        res.status(200).json(updatedUser);
    } catch (error) {
        logger.error('Error updating account status', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const addCustomer = async (req, res, next) => {
    try {
        const customerData = {
            fullname: req.body.fullname,
            mobno: req.body.mobno,
            canlogin: false, // Customers don't need login by default
            roleModels: [{ roleid: 7 }], // Customer role
            createdby: req.user.uid
        }

        const customer = await userService.addUser(customerData, req.user.uid);
        res.status(201).json(customer);
    } catch (error) {
        logger.error('Error adding customer', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const searchCustomerByMobile = async (req, res, next) => {
    try {
        const { mobile } = req.query;

        if (!mobile || mobile.length < 4) {
            return res.status(400).json({ message: 'Please enter at least 4 digits of mobile number' });
        }

        // Clean the mobile number - keep only digits
        const cleanMobile = mobile.toString().replace(/\D/g, '');

        const customers = await userService.searchCustomerByMobile(cleanMobile);

        res.status(200).json(customers);
    } catch (error) {
        logger.error('Error in searchCustomerByMobile', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

const getCustomers = async (req, res, next) => {
    try {
        const customers = await userService.getCustomers();
        res.status(200).json(customers);
    } catch (error) {
        logger.error('Error getting customers', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

export {
    addUser,
    getUserById,
    getsaveusermodal,
    editUser,
    getAllUsers,
    userSearch,
    deleteUser,
    updateProfileStatus,
    updateAccountStatus,
    addCustomer,
    searchCustomerByMobile,
    getCustomers
};