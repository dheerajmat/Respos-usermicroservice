import logger from "../utils/logger.js";

const createUnitOfMeasure = async (req, res, next) => {
    try {
        const uomData = {
            ...req.body,
            uid: req.user.uid,
            createdby: req.user.uid
          };
          const unitOfMeasure = await unitofmeasureService.createUnitOfMeasure(uomData);
          res.status(201).json(unitOfMeasure);
    } catch (error) {
        logger.error('Error creating unit of measure: ', {
            error: error.message,
            stack: error.stack
        })
        next(error);
    }
}

export {createUnitOfMeasure};