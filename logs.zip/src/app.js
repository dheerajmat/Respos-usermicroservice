import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import helmet from 'helmet';
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { promises as fs } from 'fs';
import routes from './routes/index.js';
import { errorHandler } from './middleware/errorHandler.js';
import prisma from './config/prisma.js';
import responseHandler from './middleware/responseHandler.js';
import logger from './utils/logger.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 5000;

// CORS configuration
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['Content-Disposition']
}));

// Basic middleware
app.use(express.json());
app.use(responseHandler);

// Static files handling
app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Cross-Origin-Resource-Policy', 'cross-origin');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    next();
}, express.static('uploads', {
    setHeaders: (res) => {
        res.set('Cross-Origin-Resource-Policy', 'cross-origin');
        res.set('Access-Control-Allow-Origin', '*');
    }
}));

// Performance Monitoring
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms`);
    });
    next();
});

// Swagger configuration
const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Respos API Documentation',
            version: '1.0.0',
            description: 'API Documentation with detailed specifications'
        },
        servers: [{
            url: `http://${process.env.HOST || 'localhost'}:${port}`,
            description: 'Development server'
        }],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT'
                }
            }
        },
        security: [{ bearerAuth: [] }]
    },
    apis: ['./src/routes/*.js'],
};

const specs = swaggerJsdoc(swaggerOptions);

// Swagger routes
app.use('/api-docs', swaggerUi.serve);
app.get('/api-docs', swaggerUi.setup(specs, {
    explorer: false,
    customSiteTitle: "API Documentation"
}));

// Security
app.use(helmet());

// Routes
app.use('/api/v1', routes);

app.get('/', (req, res) => {
    res.send('Welcome to Respos API! Go to /api-docs for documentation');
});

// Error handling
app.use(errorHandler);

// Database connection test
const testDatabaseConnection = async () => {
    try {
        await prisma.$connect();
        logger.info('Successfully connected to the database');
    } catch (error) {
        logger.error('Error connecting to the database:', error);
        process.exit(1);
    }
};

// Ensure default image exists
async function ensureDefaultImage() {
    const defaultImagePath = join(__dirname, '../uploads/images/default.jpg');
    try {
        await fs.access(defaultImagePath);
    } catch {
        const defaultImageDir = dirname(defaultImagePath);
        await fs.mkdir(defaultImageDir, { recursive: true });
        await fs.copyFile(
            join(__dirname, '../uploads/images/default.jpg'),
            defaultImagePath
        );
    }
}

// Start server
app.listen(port, async () => {
    await testDatabaseConnection();
    await ensureDefaultImage().catch(console.error);
    logger.info(`Server is running on http://localhost:${port}`);
    logger.info(`Swagger documentation available at http://localhost:${port}/api-docs`);
});

app.get('/uploads/images/:filename', (req, res) => {
    const filename = req.params.filename;
    const imagePath = path.join(__dirname, '../uploads/images', filename);

    res.header('Access-Control-Allow-Origin', '*');
    res.header('Cross-Origin-Resource-Policy', 'cross-origin');
    res.sendFile(imagePath);
});

// Error handlers
process.on('unhandledRejection', (err) => {
    logger.info('UNHANDLED REJECTION! Shutting down...');
    logger.info(err.name, err.message);
    process.exit(1);
});

process.on('uncaughtException', (err) => {
    logger.info('UNCAUGHT EXCEPTION! Shutting down...');
    logger.info(err.name, err.message);
    process.exit(1);
});

export default app;