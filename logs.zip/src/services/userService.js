import bcrypt from 'bcrypt';
import prisma from '../config/prisma.js';
import { AppError } from '../middleware/errorHandler.js';
import logger from '../utils/logger.js';

const addUser = async (userData, createdby) => {
    try {
        // Check if user exists
        if (userData.emailid) {
            const existingUser = await prisma.users.findFirst({
                where: {
                    emailid: userData.emailid,
                    isdeleted: false
                }
            });

            if (existingUser) {
                throw new AppError('User with this email already exists', 400);
            }
        }

        // Hash password if provided
        const hashedPassword = userData.password ? await bcrypt.hash(userData.password, 10) : null;

        // Use transaction to ensure data consistency
        return await prisma.$transaction(async (tx) => {
            // Create the user
            const user = await tx.users.create({
                data: {
                    fullname: userData.fullname,
                    firstname: userData.firstname || null,
                    lastname: userData.lastname || null,
                    emailid: userData.emailid || null,
                    mobno: userData.mobno || null,
                    employee_id: userData.employeeid || null,
                    canlogin: userData.canlogin ?? true,
                    password: hashedPassword,
                    usercode: userData.usercode || null,
                    image: userData.image || null,
                    // Set these to null if not provided or convert to BigInt if provided
                    profilestatus: userData.profilestatus ? BigInt(userData.profilestatus) : null,
                    accountstatus: userData.accountstatus ? BigInt(userData.accountstatus) : null,
                    isapproved: userData.isapproved ?? false,
                    isdeleted: false,
                    createdby: createdby ? BigInt(createdby) : null,
                    createddate: new Date(),
                    marketsegement: userData.marketsegement ? BigInt(userData.marketsegement) : null,
                    languageid: userData.languageid ? BigInt(userData.languageid) : null,
                    currencyid: userData.currencyid ? BigInt(userData.currencyid) : null,
                    isadmin: userData.isadmin ?? false
                }
            });

            // Create role mappings if provided
            if (userData.roleModels && userData.roleModels.length > 0) {
                await tx.userrolemapping.createMany({
                    data: userData.roleModels.map(role => ({
                        uid: user.uid,
                        uoid: role.uoid ? BigInt(role.uoid) : null,
                        roleid: role.roleid ? BigInt(role.roleid) : null,
                        roletypeid: role.roletypeid ? BigInt(role.roletypeid) : null,
                        isdeleted: false,
                        createdby: createdby ? BigInt(createdby) : null,
                        createddate: new Date()
                    }))
                });
            }

            // Create rights mappings if provided
            if (userData.rightsOfUserModel?.modules) {
                const rightsToCreate = userData.rightsOfUserModel.modules
                    .flatMap(module =>
                        module.rightsList
                            .filter(right => right.selected)
                            .map(right => ({
                                userid: user.uid,
                                rightid: BigInt(right.rightId),
                                Isdeleted: false,
                                // createddate: new Date()
                            }))
                    );

                if (rightsToCreate.length > 0) {
                    await tx.userrightsmapping.createMany({
                        data: rightsToCreate
                    });
                }
            }

            // Remove sensitive data before returning
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
        });

    } catch (error) {
        logger.error('Error adding user', {
            error: error.message,
            stack: error.stack,
            userData
        });
        throw error;
    }
};

const getUserById = async (id) => {
    try {
        const user = await prisma.users.findUnique({
            where: { uid: id }
        })
        return user;
    } catch (error) {
        logger.error('Error getting user by id', {
            error: error.message,
            stack: error.stack,
            id
        })
        throw error;
    }
}

const editUser = async (userId, userData, modifiedby) => {
    try {
        logger.info('Starting user update transaction', {
            userId,
            updateData: JSON.stringify(userData)
        });

        return await prisma.$transaction(async (tx) => {
            // Hash password if provided
            if (userData.password) {
                userData.password = await bcrypt.hash(userData.password, 10);
            }

            // Update user basic information
            const updatedUser = await tx.users.update({
                where: {
                    uid: BigInt(userId)
                },
                data: {
                    fullname: userData.fullname,
                    firstname: userData.firstname,
                    lastname: userData.lastname,
                    emailid: userData.emailid,
                    mobno: userData.mobno,
                    canlogin: userData.canlogin,
                    password: userData.password,
                    usercode: userData.usercode,
                    image: userData.image,
                    profilestatus: userData.profilestatus ? BigInt(userData.profilestatus) : null,
                    isapproved: userData.isapproved,
                    accountstatus: userData.accountstatus ? BigInt(userData.accountstatus) : null,
                    isadmin: userData.isadmin,
                    modifiedby: BigInt(modifiedby),
                    modifieddate: new Date()
                }
            });

            // Handle role mappings
            if (userData.roleModels && Array.isArray(userData.roleModels)) {
                // Delete existing role mappings
                await tx.userrolemapping.deleteMany({
                    where: {
                        uid: BigInt(userId)
                    }
                });

                // Create new role mappings
                if (userData.roleModels.length > 0) {
                    await tx.userrolemapping.createMany({
                        data: userData.roleModels.map(role => ({
                            uid: BigInt(userId),
                            uoid: role.uoid ? BigInt(role.uoid) : null,
                            roleid: role.roleid ? BigInt(role.roleid) : null,
                            roletypeid: role.roletypeid ? BigInt(role.roletypeid) : null,
                            isdeleted: false,
                            createdby: BigInt(modifiedby),
                            createddate: new Date(),
                            modifiedby: BigInt(modifiedby),
                            modifieddate: new Date()
                        }))
                    });
                }
            }

            // Handle rights mappings
            if (userData.rightsOfUserModel?.modules) {
                // Delete existing rights mappings
                await tx.userrightsmapping.deleteMany({
                    where: {
                        userid: BigInt(userId)
                    }
                });

                const rightsToCreate = userData.rightsOfUserModel.modules
                    .flatMap(module =>
                        module.rightsList
                            .filter(right => right.selected)
                            .map(right => ({
                                userid: BigInt(userId),
                                rightid: BigInt(right.rightId || 0),
                                Modifiedby: BigInt(modifiedby),
                                Isdeleted: false
                            }))
                    );

                if (rightsToCreate.length > 0) {
                    await tx.userrightsmapping.createMany({
                        data: rightsToCreate
                    });
                }
            }

            // Get updated user data
            const updatedUserData = await tx.users.findUnique({
                where: {
                    uid: BigInt(userId)
                }
            });

            // Get role mappings separately
            const roleMappings = await tx.userrolemapping.findMany({
                where: {
                    uid: BigInt(userId),
                    isdeleted: false
                }
            });

            // Get rights mappings separately
            const rightsMappings = await tx.userrightsmapping.findMany({
                where: {
                    userid: BigInt(userId),
                    Isdeleted: false
                }
            });

            // Combine the data
            return {
                ...updatedUserData,
                role_mappings: roleMappings,
                rights_mappings: rightsMappings
            };
        });

    } catch (error) {
        logger.error('Error updating user', {
            error: error.message,
            stack: error.stack,
            userId,
            userData: JSON.stringify(userData)
        });

        if (error.code === 'P2002') {
            throw new AppError('Email already exists', 400);
        }

        throw error;
    }
};

const getUserRoles = async (userId) => {
    try {
        return await prisma.userrolemapping.findMany({
            where: {
                uid: BigInt(userId),
                isdeleted: false
            }
        });
    } catch (error) {
        logger.error('Error fetching user roles', {
            error: error.message,
            userId
        });
        throw error;
    }
};

const getUserRights = async (userId) => {
    try {
        return await prisma.userrightsmapping.findMany({
            where: {
                userid: BigInt(userId),
                Isdeleted: false
            }
        });
    } catch (error) {
        logger.error('Error fetching user rights', {
            error: error.message,
            userId
        });
        throw error;
    }
};

const getAllUsers = async (uoid) => {
    try {
        return await prisma.userlogin.findMany({
            where: {
                uoid: BigInt(uoid),
                isdeleted: false
            }
        })
    } catch (error) {
        logger.error('Error fetching all users', {
            error: error.message,
            uoid
        });
        throw error;
    }
}

const userSearch = async (searchTerms, pagination) => {
    try {
        const { name, role, status, uoid } = searchTerms;
        const { itemsPerPage = 10, currentPage = 1 } = pagination;

        // Calculate offset for pagination
        const skip = (currentPage - 1) * itemsPerPage;

        // Build the base "where" clause using Prisma conditions
        const whereConditions = {
            isdeleted: false,
            roleid_orgid: BigInt(uoid),
        };

        // Add name condition (case-insensitive partial match)
        if (name) {
            whereConditions.fullname = {
                contains: name,
                mode: 'insensitive',
            };
        }

        // Add profile status condition (1 for active, 0 for inactive)
        if (status) {
            whereConditions.profilestatus = BigInt(status === "1" ? 1 : 0);
        }

        // Add role condition
        if (role) {
            whereConditions.roleid = BigInt(role);
        }

        // Fetch total count of users matching the conditions
        const totalUsers = await prisma.userlogin.count({
            where: whereConditions,
        });

        // Fetch users with pagination
        const users = await prisma.userlogin.findMany({
            where: whereConditions,
            orderBy: { uid: 'asc' },
            skip: skip,
            take: itemsPerPage,
        });

        // Transform BigInt values into numbers for JavaScript compatibility
        const transformedUsers = users.map((user) => ({
            ...user,
            uid: Number(user.uid),
            roleid: user.roleid ? Number(user.roleid) : null,
            roleid_orgid: user.roleid_orgid ? Number(user.roleid_orgid) : null,
            profilestatus: user.profilestatus ? Number(user.profilestatus) : null,
        }));

        // Return paginated results
        return {
            users: transformedUsers,
            totalUsers,
            pagination: {
                itemsPerPage,
                currentPage,
                totalPages: Math.ceil(totalUsers / itemsPerPage),
            },
        };
    } catch (error) {
        logger.error('Error searching users:', {
            error: error.message,
            stack: error.stack,
        });
        throw error;
    }
};

const deleteUser = async (userId, deletedby) => {
    try {
        return await prisma.users.update({
            where: { uid: BigInt(userId) },
            data: {
                isdeleted: true,
                deletedby: BigInt(deletedby),
                deleteddate: new Date()
            }
        })
    } catch (error) {
        logger.error('Error deleting user', {
            error: error.message,
            stack: error.stack,
            userId
        })
        throw error;
    }
}

const updateProfileStatus = async (userId, profileStatus) => {
    try {
        return await prisma.users.update({
            where: { uid: BigInt(userId) },
            data: {
                profilestatus: BigInt(profileStatus)
            }
        })
    } catch (error) {
        logger.error('Error updating profile status', {
            error: error.message,
            stack: error.stack,
            userId
        })
        throw error;
    }
}

const updateAccountStatus = async (userId, accountStatus) => {
    try {
        return await prisma.users.update({
            where: { uid: BigInt(userId) },
            data: {
                accountstatus: BigInt(accountStatus)
            }
        })
    } catch (error) {
        logger.error('Error updating account status', {
            error: error.message,
            stack: error.stack,
            userId
        })
        throw error;
    }
}

const searchCustomerByMobile = async (mobileNumber) => {
    try {
        return await prisma.users.findMany({
            where: {
                mobno: {
                    startsWith: mobileNumber, // Similar to 'LIKE $1' in SQL
                },
                isdeleted: false, // Ensuring the user is not deleted
                userrolemapping: {
                    some: {
                        roleid: 7, // Filtering by roleid
                        isdeleted: false, // Ensuring the user role mapping is not deleted
                    },
                },
            },
            select: {
                uid: true,
                fullname: true,
                mobno: true,
            },
            take: 10, // Limiting the number of results
        });
    } catch (error) {
        logger.error('Error in searchCustomerByMobile:', {
            error: error.message,
            stack: error.stack,
        });
        throw error;
    }
};

// const getCustomers = async () => {
//     try {
//         const customers = await prisma.users.findMany({
//             where: {
//                 isdeleted: false, // Ensure users are not deleted
//                 userrolemapping: {
//                     some: {
//                         roleid: 7, // Only include users with roleid = 7
//                         isdeleted: false, // Ensure role mapping is not deleted
//                     },
//                 },
//             },
//             orderBy: {
//                 createddate: 'desc', // Order by createddate in descending order
//             },
//             include: {
//                 userrolemapping: {
//                     where: {
//                         isdeleted: false, // Include role mappings that are not deleted
//                     },
//                 },
//             },
//         });

//         return customers;
//     } catch (error) {
//         logger.error('Database error', {
//             error: error.message,
//             service: 'respos-api',
//             target: 'users.findMany',
//         });
//         throw error;
//     }
// };

const getCustomers = async () => {
    try {
        const customers = await prisma.users.findMany({
            where: {
                isdeleted: false,
                userrolemapping_userrolemapping_uidTousers: {  // Using the correct relation name from your schema
                    some: {
                        roleid: 7,
                        isdeleted: false,
                    },
                },
            },
            orderBy: {
                createddate: 'desc',
            },
            include: {
                userrolemapping_userrolemapping_uidTousers: {  // Include the correct relation
                    where: {
                        isdeleted: false,
                    },
                },
            },
        });

        // Rename the key in the response
        const formattedCustomers = customers.map((customer) => {
            const { userrolemapping_userrolemapping_uidTousers, ...rest } = customer;
            return {
                ...rest,
                userrolemapping: userrolemapping_userrolemapping_uidTousers,
            };
        });

        return formattedCustomers;
    } catch (error) {
        logger.error('Database error', {
            error: error.message,
            service: 'respos-api',
            target: 'users.findMany',
        });
        throw error;
    }
};

export {
    addUser,
    getUserById,
    editUser,
    getUserRoles,
    getUserRights,
    getAllUsers,
    userSearch,
    deleteUser,
    updateProfileStatus,
    updateAccountStatus,
    searchCustomerByMobile,
    getCustomers
};

