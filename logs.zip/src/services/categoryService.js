import prisma from "../config/prisma.js";
import logger from "../utils/logger.js";

const getCategoryToCreateModal = async () => {
    try {
        const dropdownData = await prisma.categories.findMany({
            where: {
                isdeleted: false,
            },
            select: {
                catid: true,
                catname: true
            }
        });

        return {
            modal: {
                catname: "",
                categorytype: 0,
                catdesc: "",
                catfullpath: "",
                parentcatid: 0,
                orderno: 0,
                ispublished: true,
                displayorder: 0
            },
            dropdown: dropdownData
        };
    } catch (error) {
        logger.error('Error getting category modal', {
            error: error.message,
            stack: error.stack,
        });
        throw error;
    }
}

const searchCategories = async ({ catname, ispublished, page, limit }) => {
    try {
        const offset = (page - 1) * limit;

        // Build where condition
        const whereConditions = {
            isdeleted: false,
            ...(catname && {
                catname: {
                    contains: catname,
                    mode: 'insensitive'  // This is equivalent to ILIKE
                }
            }),
            ...(ispublished !== undefined && { ispublished: ispublished })
        };

        // Get total count of categories
        const totalCount = await prisma.categories.count({
            where: whereConditions
        });

        // Get paginated categories
        const categories = await prisma.categories.findMany({
            where: whereConditions,
            orderBy: {
                catid: 'desc'
            },
            skip: offset,
            take: limit,
            select: {
                catid: true,
                catname: true,
                categorytype: true,
                catdesc: true,
                catfullpath: true,
                parentcatid: true,
                orderno: true,
                ispublished: true,
                displayorder: true,
                createddate: true,
                modifieddate: true
            }
        })

        return {
            categories,
            totalCount,
            currentPage: page,
            totalPages: Math.ceil(totalCount / limit)
        };
    } catch (error) {
        logger.error('Error searching categories', {
            error: error.message,
            stack: error.stack,
        });
        throw error;
    }
}

const createCategory = async (categoryData, createdby) => {
    try {
        const category = await prisma.categories.create({
            data: {
                catname: categoryData.catname,
                categorytype: categoryData.categorytype,
                catdesc: categoryData.catdesc,
                catfullpath: categoryData.catfullpath,
                parentcatid: categoryData.parentcatid,
                orderno: categoryData.orderno,
                ispublished: categoryData.ispublished,
                displayorder: categoryData.displayorder,
                createdby: createdby
            }
        })

        return category;
    } catch (error) {
        logger.error('Error creating category', {
            error: error.message,
            stack: error.stack,
        });
        throw error;
    }
}

const getCategories = async () => {
    try {
        const categories = await prisma.categories.findMany({
            where: {
                isdeleted: false
            }
        });
        return categories;
    } catch (error) {
        logger.error('Error getting categories', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

const getCategoryById = async (id) => {
    try {
        const category = await prisma.categories.findFirst({
            where: {
                catid: id
            }
        });
        return category;
    } catch (error) {
        logger.error('Error getting category by id', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

const updateCategory = async (catid, categoryData, modifiedby) => {
    try {
        const updatedCategory = await prisma.categories.update({
            where: {
                catid: catid,
            },
            data: {
                catname: categoryData.catname,
                categorytype: categoryData.categorytype,
                catdesc: categoryData.catdesc,
                catfullpath: categoryData.catfullpath,
                parentcatid: categoryData.parentcatid,
                orderno: categoryData.orderno,
                ispublished: categoryData.ispublished,
                displayorder: categoryData.displayorder,
                modifiedby: modifiedby,
                modifieddate: new Date()
            }
        })
        return updatedCategory;
    } catch (error) {
        logger.error('Error updating category', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

const deleteCategory = async (catid, deletedby) => {
    try {
        return await prisma.categories.update({
            where: {
                catid: catid
            },
            data: {
                isdeleted: true,
                deletedby: deletedby,
                deleteddate: new Date()
            }
        })
    } catch (error) {
        logger.error('Error deleting category', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

export { getCategoryToCreateModal, searchCategories, createCategory, getCategories, getCategoryById, updateCategory, deleteCategory };