import express from 'express';


const router = express.Router();



/**
 * @swagger
 * /api/unitofmeasure:
 *   post:
 *     summary: Create a new unit of measure
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - uomname
 *               - uomsymbole
 *               - catid
 *               - uid
 *             properties:
 *               uomname:
 *                 type: string
 *               uomsymbole:
 *                 type: string
 *               catid:
 *                 type: integer
 *               uid:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Unit of measure created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 unitOfMeasure:
 *                   type: object
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.post('/', createUnitOfMeasure);

/**
 * @swagger
 * /api/unitofmeasure:
 *   get:
 *     summary: Retrieve all units of measure
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of units of measure
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   uomid:
 *                     type: integer
 *                   uomname:
 *                     type: string
 *                   uomsymbole:
 *                     type: string
 *                   catid:
 *                     type: integer
 *                   uid:
 *                     type: integer
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get('/',authMiddleware, UnitOfMeasureController.getUnitOfMeasures);

/**
 * @swagger
 * /api/unitofmeasure/conversions:
 *   get:
 *     summary: Get all UOM conversions
 *     tags: [UOM Conversions]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of UOM conversions
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   uomcid:
 *                     type: integer
 *                   catid:
 *                     type: integer
 *                   uomfrom:
 *                     type: integer
 *                   uomto:
 *                     type: integer
 *                   uomvalue:
 *                     type: number
 *                   from_uom:
 *                     type: string
 *                   to_uom:
 *                     type: string
 */
router.get('/conversions', authMiddleware, UOMConversionController.getUOMConversions);

/**
 * @swagger
 * /api/unitofmeasure/{id}:
 *   get:
 *     summary: Retrieve a unit of measure by ID
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID of the unit of measure to retrieve
 *     responses:
 *       200:
 *         description: The unit of measure data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 uomid:
 *                   type: integer
 *                 uomname:
 *                   type: string
 *                 uomsymbole:
 *                   type: string
 *                 catid:
 *                   type: integer
 *                 uid:
 *                   type: integer
 *       404:
 *         description: Unit of measure not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get('/:id',authMiddleware, UnitOfMeasureController.getUnitOfMeasureById);

/**
 * @swagger
 * /api/unitofmeasure/{id}:
 *   put:
 *     summary: Update a unit of measure
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID of the unit of measure to update
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               uomname:
 *                 type: string
 *               uomsymbole:
 *                 type: string
 *               catid:
 *                 type: integer
 *               uid:
 *                 type: integer
 *               modifiedby:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Unit of measure updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 unitOfMeasure:
 *                   type: object
 *       400:
 *         description: Bad request
 *       404:
 *         description: Unit of measure not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.put('/:id',authMiddleware, UnitOfMeasureController.updateUnitOfMeasure);

/**
 * @swagger
 * /api/unitofmeasure/{id}:
 *   delete:
 *     summary: Soft delete a unit of measure
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID of the unit of measure to delete
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               deletedby:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Unit of measure soft-deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *       404:
 *         description: Unit of measure not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.delete('/:id',authMiddleware, UnitOfMeasureController.deleteUnitOfMeasure);

/**
 * @swagger
 * /api/unitofmeasure/hard-delete/{id}:
 *   delete:
 *     summary: Hard delete a unit of measure
 *     tags: [Unit of Measure]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID of the unit of measure to hard delete
 *     responses:
 *       200:
 *         description: Unit of measure permanently deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *       404:
 *         description: Unit of measure not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.delete('/hard-delete/:id',authMiddleware, UnitOfMeasureController.hardDeleteUnitOfMeasure);

/**
 * @swagger
 * /api/unitofmeasure/conversions:
 *   post:
 *     summary: Create a new UOM conversion
 *     tags: [UOM Conversions]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - catid
 *               - uomfrom
 *               - uomto
 *               - uomvalue
 *             properties:
 *               catid:
 *                 type: integer
 *                 description: Category ID
 *               uomfrom:
 *                 type: integer
 *                 description: Source UOM ID
 *               uomto:
 *                 type: integer
 *                 description: Target UOM ID
 *               uomvalue:
 *                 type: number
 *                 description: Conversion value
 *     responses:
 *       201:
 *         description: UOM conversion created successfully
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.post('/conversions', authMiddleware, UOMConversionController.createUOMConversion);

/**
 * @swagger
 * /api/unitofmeasure/conversions/{id}:
 *   get:
 *     summary: Get a UOM conversion by ID
 *     tags: [UOM Conversions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: UOM conversion ID
 *     responses:
 *       200:
 *         description: UOM conversion details
 *       404:
 *         description: UOM conversion not found
 */
router.get('/conversions/:id', authMiddleware, UOMConversionController.getUOMConversionById);

/**
 * @swagger
 * /api/unitofmeasure/conversions/{id}:
 *   put:
 *     summary: Update a UOM conversion
 *     tags: [UOM Conversions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: UOM conversion ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               catid:
 *                 type: integer
 *               uomfrom:
 *                 type: integer
 *               uomto:
 *                 type: integer
 *               uomvalue:
 *                 type: number
 *     responses:
 *       200:
 *         description: UOM conversion updated successfully
 *       404:
 *         description: UOM conversion not found
 */
router.put('/conversions/:id', authMiddleware, UOMConversionController.updateUOMConversion);

/**
 * @swagger
 * /api/unitofmeasure/conversions/{id}:
 *   delete:
 *     summary: Delete a UOM conversion
 *     tags: [UOM Conversions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: UOM conversion ID
 *     responses:
 *       200:
 *         description: UOM conversion deleted successfully
 *       404:
 *         description: UOM conversion not found
 */
router.delete('/conversions/:id', authMiddleware, UOMConversionController.deleteUOMConversion);

export default router;