import express from 'express';
import { addCustomer, addUser, deleteUser, editUser, getAllUsers, getCustomers, getsaveusermodal, getUserById, searchCustomerByMobile, updateAccountStatus, updateProfileStatus, userSearch } from '../controllers/userController.js';

const router = express.Router();


/**
 * @swagger
 * /api/v1/users/search-customer:
 *   get:
 *     summary: Search customers by mobile number
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: mobile
 *         required: true
 *         schema:
 *           type: string
 *         description: Mobile number (minimum 4 digits)
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       uid:
 *                         type: integer
 *                       fullname:
 *                         type: string
 *                       mobno:
 *                         type: string
 *                 message:
 *                   type: string
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.get('/search-customer', searchCustomerByMobile);


/**
 * @swagger
 * /api/v1/users/customers:
 *   get:
 *     summary: Get all customers (users with role 7)
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of customers retrieved successfully
 *       500:
 *         description: Server error
 */
router.get('/customers', getCustomers);


/**
 * @swagger
 * components:
 *   schemas:
 *     RightsList:
 *       type: object
 *       required:
 *         - rightId
 *         - rightName
 *         - selected
 *       properties:
 *         rightId:
 *           type: integer
 *           description: The ID of the right
 *         rightName:
 *           type: string
 *           description: The name of the right
 *         selected:
 *           type: boolean
 *           description: Whether the right is selected
 *     Module:
 *       type: object
 *       required:
 *         - moduleName
 *         - rightsList
 *       properties:
 *         moduleName:
 *           type: string
 *           description: The name of the module
 *         rightsList:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/RightsList'
 *     RightsOfUserModel:
 *       type: object
 *       required:
 *         - modules
 *       properties:
 *         modules:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Module'
 *     RoleModel:
 *       type: object
 *       required:
 *         - uoid
 *         - roleid
 *         - roletypeid
 *       properties:
 *         uoid:
 *           type: integer
 *           description: The organization ID
 *         roleid:
 *           type: integer
 *           description: The role ID
 *         roletypeid:
 *           type: integer
 *           description: The role type ID
 *     User:
 *       type: object
 *       required:
 *         - fullname
 *         - firstname
 *         - lastname
 *         - emailid
 *         - mobno
 *         - employeeid
 *         - canlogin
 *         - password
 *         - usercode
 *         - profilestatus
 *         - isapproved
 *         - accountstatus
 *         - roleid
 *         - roleName
 *         - roleModels
 *         - rightsOfUserModel
 *       properties:
 *         fullname:
 *           type: string
 *           description: The full name of the user
 *         firstname:
 *           type: string
 *           description: The first name of the user
 *         lastname:
 *           type: string
 *           description: The last name of the user
 *         emailid:
 *           type: string
 *           description: The email of the user
 *         mobno:
 *           type: string
 *           description: The mobile number of the user
 *         employeeid:
 *           type: string
 *           description: The employee ID of the user
 *         canlogin:
 *           type: boolean
 *           description: Whether the user can login
 *         password:
 *           type: string
 *           description: The password of the user
 *         usercode:
 *           type: string
 *           description: The user code
 *         image:
 *           type: string
 *           description: The user's image URL
 *         profilestatus:
 *           type: integer
 *           description: The profile status
 *         isapproved:
 *           type: boolean
 *           description: Whether the user is approved
 *         accountstatus:
 *           type: integer
 *           description: The account status
 *         roleid:
 *           type: integer
 *           description: The role ID
 *         roleName:
 *           type: string
 *           description: The role name
 *         roleModels:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/RoleModel'
 *         rightsOfUserModel:
 *           $ref: '#/components/schemas/RightsOfUserModel'
 *     UserResponse:
 *       type: object
 *       properties:
 *         uid:
 *           type: integer
 *           description: The user ID
 *         fullname:
 *           type: string
 *           description: The full name of the user
 *         emailid:
 *           type: string
 *           description: The email of the user
 *         message:
 *           type: string
 *           description: A success message
 */



/**
 * @swagger
 * /api/v1/users/getsaveusermodal:
 *   get:
 *     summary: Get save user modal data
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/User'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.get('/getsaveusermodal', getsaveusermodal);


/**
 * @swagger
 * /api/v1/users:
 *   post:
 *     summary: Create a new user
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/User'
 *     responses:
 *       201:
 *         description: User created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UserResponse'
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Server error
 */
router.post('/', addUser);


/**
 * @swagger
 * /api/v1/users/{id}:
 *   get:
 *     summary: Get a user by ID
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: User ID
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     user:
 *                       type: object
 *                       properties:
 *                         uid:
 *                           type: integer
 *                         fullname:
 *                           type: string
 *                         emailid:
 *                           type: string
 *                         role_mappings:
 *                           type: array
 *                           items:
 *                             type: object
 *                         rights_mappings:
 *                           type: array
 *                           items:
 *                             type: object
 *       404:
 *         description: User not found
 */
router.get('/:id', getUserById);



/**
 * @swagger
 * /api/v1/users/updateusers/{id}:
 *   put:
 *     summary: Update a user
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               fullname:
 *                 type: string
 *               firstname:
 *                 type: string
 *               lastname:
 *                 type: string
 *               emailid:
 *                 type: string
 *               mobno:
 *                 type: string
 *               canlogin:
 *                 type: boolean
 *               password:
 *                 type: string
 *               usercode:
 *                 type: string
 *               image:
 *                 type: string
 *               profilestatus:
 *                 type: integer
 *               isapproved:
 *                 type: boolean
 *               accountstatus:
 *                 type: integer
 *               isadmin:
 *                 type: boolean
 *               updatedby:
 *                 type: integer
 *               roleModels:
 *                 type: array
 *                 items:
 *                   $ref: '#/components/schemas/RoleModel'
 *               rightsOfUserModel:
 *                 $ref: '#/components/schemas/RightsOfUserModel'
 *     responses:
 *       200:
 *         description: User updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   properties:
 *                     uid:
 *                       type: integer
 *                     fullname:
 *                       type: string
 *                     emailid:
 *                       type: string
 *                     role_mappings:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/RoleModel'
 *                     rights_mappings:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           rightid:
 *                             type: integer
 *       400:
 *         description: Invalid input
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.put('/updateusers/:id', editUser);


/**
 * @swagger
 * /api/v1/users:
 *   get:
 *     summary: Get all users
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Success
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       uid:
 *                         type: integer
 *                       fullname:
 *                         type: string
 *                       emailid:
 *                         type: string
 *                       role_mappings:
 *                         type: array
 *                         items:
 *                           $ref: '#/components/schemas/RoleModel'
 *                       rights_mappings:
 *                         type: array
 *                         items:
 *                           type: object
 *                           properties:
 *                             rightid:
 *                               type: integer
 */
router.get('/', getAllUsers);


/**
 * @swagger
 * /api/v1/users/filter:
 *   post:
 *     summary: Search for users
 *     description: Searches for users based on provided parameters such as name, status, and role, with pagination support.
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Name of the user to search for (supports partial matching).
 *                 example: John Doe
 *               status:
 *                 type: string
 *                 description: Status of the user (e.g., active, inactive).
 *                 example: active
 *               role:
 *                 type: integer
 *                 description: Role of the user (e.g., admin, user) to filter by.
 *                 example: 1
 *               pagination:
 *                 type: object
 *                 properties:
 *                   itemPerPage:
 *                     type: integer
 *                     description: Number of items per page.
 *                     example: 10
 *                   currentPage:
 *                     type: integer
 *                     description: The current page number for pagination.
 *                     example: 1
 *     responses:
 *       200:
 *         description: Successful search operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 users:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       uid:
 *                         type: string
 *                         description: Unique ID of the user
 *                         example: "12345"
 *                       fullname:
 *                         type: string
 *                         description: Full name of the user
 *                         example: "John Doe"
 *                       accountstatus:
 *                         type: string
 *                         description: Status of the user's account
 *                         example: "active"
 *                       rolename:
 *                         type: string
 *                         description: Role of the user
 *                         example: "user"
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     totalUsers:
 *                       type: integer
 *                       description: Total number of users matching the search criteria.
 *                       example: 100
 *                     totalPages:
 *                       type: integer
 *                       description: Total number of pages based on the pagination.
 *                       example: 10
 *                     itemPerPage:
 *                       type: integer
 *                       description: Number of items per page.
 *                       example: 10
 *                     currentPage:
 *                       type: integer
 *                       description: The current page number.
 *                       example: 1
 *       400:
 *         description: Invalid input
 *       500:
 *         description: Internal server error
 */

router.post('/filter', userSearch);


/**
 * @swagger
 * /api/v1/users/delete/{id}:
 *   delete:
 *     summary: Mark a user as deleted
 *     description: Sets the "isdeleted" field to true for a specific user without removing them from the database.
 *     tags:
 *       - Users
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Unique ID of the user to be deleted
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User successfully marked as deleted
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: User marked as deleted successfully
 *       404:
 *         description: User not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: User not found
 *       500:
 *         description: Server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: Internal server error
 */

router.delete('/delete/:id', deleteUser);

/**
 * @swagger
 * /api/v1/users/{id}/profile-status:
 *   patch:
 *     summary: Update user profile status
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - profileStatus
 *             properties:
 *               profileStatus:
 *                 type: integer
 *                 description: New profile status
 *     responses:
 *       200:
 *         description: Profile status updated successfully
 *       500:
 *         description: Server error
 */
router.patch('/:id/profile-status', updateProfileStatus);

/**
 * @swagger
 * /api/v1/users/{id}/account-status:
 *   patch:
 *     summary: Update user account status
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - accountStatus
 *             properties:
 *               accountStatus:
 *                 type: integer
 *                 description: New account status
 *     responses:
 *       200:
 *         description: Account status updated successfully
 *       500:
 *         description: Server error
 */
router.patch('/:id/account-status', updateAccountStatus);

/**
 * @swagger
 * /api/v1/users/customer:
 *   post:
 *     summary: Add a new customer
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - fullname
 *               - mobno
 *             properties:
 *               fullname:
 *                 type: string
 *                 description: Customer's full name
 *               mobno:
 *                 type: string
 *                 description: Customer's mobile number
 *     responses:
 *       201:
 *         description: Customer created successfully
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.post('/customer', addCustomer);


// /**
//  * @swagger
//  * /api/users/{userId}/orders:
//  *   get:
//  *     summary: Get all orders for a specific user
//  *     tags: [Users]
//  *     security:
//  *       - bearerAuth: []
//  *     parameters:
//  *       - in: path
//  *         name: userId
//  *         required: true
//  *         schema:
//  *           type: integer
//  *         description: User ID
//  *     responses:
//  *       200:
//  *         description: User orders retrieved successfully
//  *       404:
//  *         description: User not found
//  *       500:
//  *         description: Server error
//  */
// router.get('/:userId/orders', getUserOrders);

export default router;