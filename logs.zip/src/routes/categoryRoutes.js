import express from 'express';
import { createCategory, deleteCategory, getCategories, getCategoryById, getCategoryToCreateModal, searchCategories, updateCategory } from '../controllers/categoryController.js';

const router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Category:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           description: The category ID
 *         catname:
 *           type: string
 *           description: The name of the category
 *         categorytype:
 *           type: integer
 *           description: The type of category
 *         catdesc:
 *           type: string
 *           description: Category description
 *         catfullpath:
 *           type: string
 *           description: Full path of the category
 *         parentcatid:
 *           type: integer
 *           description: ID of the parent category
 *         orderno:
 *           type: integer
 *           description: Order number
 *         ispublished:
 *           type: boolean
 *           description: Publication status
 *         displayorder:
 *           type: integer
 *           description: Display order
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 */



/**
 * @swagger
 * /api/v1/categories/modal:
 *   get:
 *     summary: Get category creation modal with dropdown data
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Modal template and dropdown data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 modal:
 *                   type: object
 *                   properties:
 *                     catname:
 *                       type: string
 *                     categorytype:
 *                       type: integer
 *                     catdesc:
 *                       type: string
 *                     catfullpath:
 *                       type: string
 *                     parentcatid:
 *                       type: integer
 *                     orderno:
 *                       type: integer
 *                     ispublished:
 *                       type: boolean
 *                     displayorder:
 *                       type: integer
 *                 dropdown:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: integer
 *                       catname:
 *                         type: string
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get('/modal', getCategoryToCreateModal);

/**
 * @swagger
 * /api/v1/categories/search:
 *   post:
 *     summary: Search categories by name and status with pagination
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               catname:
 *                 type: string
 *                 description: Category name to search for
 *               ispublished:
 *                 type: string
 *                 enum: ['true', 'false']
 *                 description: Filter by published status
 *               page:
 *                 type: integer
 *                 minimum: 1
 *                 default: 1
 *                 description: Page number
 *               limit:
 *                 type: integer
 *                 minimum: 1
 *                 default: 10
 *                 description: Number of items per page
 *     responses:
 *       200:
 *         description: Paginated search results
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Category'
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     totalItems:
 *                       type: integer
 *                     currentPage:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *                     itemsPerPage:
 *                       type: integer
 */
router.post('/search', searchCategories);

/**
 * @swagger
 * /api/v1/categories/add:
 *   post:
 *     summary: Add a new category
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - catname
 *               - categorytype
 *             properties:
 *               catname:
 *                 type: string
 *               categorytype:
 *                 type: integer
 *               catdesc:
 *                 type: string
 *               catfullpath:
 *                 type: string
 *               parentcatid:
 *                 type: integer
 *               orderno:
 *                 type: integer
 *               ispublished:
 *                 type: boolean
 *               displayorder:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Category added successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 category:
 *                   type: object
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.post('/add', createCategory);

/**
 * @swagger
 * /api/v1/categories:
 *   get:
 *     summary: Get all categories
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of categories
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get('/', getCategories);

/**
 * @swagger
 * /api/v1/categories/{id}:
 *   get:
 *     summary: Get a category by ID
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The category ID
 *     responses:
 *       200:
 *         description: The category data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *       404:
 *         description: Category not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
router.get('/:id', getCategoryById);

/**
 * @swagger
 * /api/v1/categories/{id}:
 *   put:
 *     summary: Update a category by ID
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The category ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               catname:
 *                 type: string
 *               categorytype:
 *                 type: integer
 *               catdesc:
 *                 type: string
 *               catfullpath:
 *                 type: string
 *               parentcatid:
 *                 type: integer
 *               orderno:
 *                 type: integer
 *               ispublished:
 *                 type: boolean
 *               displayorder:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Category updated successfully
 *       404:
 *         description: Category not found
 *       400:
 *         description: Bad request
 *       500:
 *         description: Internal server error
 */
router.put('/:id', updateCategory);

/**
 * @swagger
 * /api/v1/categories/{id}:
 *   delete:
 *     summary: Soft delete a category by ID
 *     tags: [Category]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: The category ID
 *     responses:
 *       200:
 *         description: Category soft deleted successfully
 *       404:
 *         description: Category not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:id', deleteCategory);

// /**
//  * @swagger
//  * /api/v1/categories/filter:
//  *   post:
//  *     summary: Filter categories with pagination
//  *     tags: [Category]
//  *     security:
//  *       - bearerAuth: []
//  *     requestBody:
//  *       required: true
//  *       content:
//  *         application/json:
//  *           schema:
//  *             type: object
//  *             properties:
//  *               catname:
//  *                 type: string
//  *                 description: Category name to filter by
//  *               ispublished:
//  *                 type: string
//  *                 enum: ['true', 'false']
//  *                 description: Filter by published status
//  *               page:
//  *                 type: integer
//  *                 minimum: 1
//  *                 default: 1
//  *                 description: Page number
//  *               limit:
//  *                 type: integer
//  *                 minimum: 1
//  *                 default: 10
//  *                 description: Number of items per page
//  *     responses:
//  *       200:
//  *         description: Filtered list of categories
//  *         content:
//  *           application/json:
//  *             schema:
//  *               type: object
//  *               properties:
//  *                 success:
//  *                   type: boolean
//  *                 data:
//  *                   type: array
//  *                   items:
//  *                     $ref: '#/components/schemas/Category'
//  *                 pagination:
//  *                   type: object
//  *                   properties:
//  *                     totalItems:
//  *                       type: integer
//  *                     currentPage:
//  *                       type: integer
//  *                     totalPages:
//  *                       type: integer
//  *                     itemsPerPage:
//  *                       type: integer
//  */
// router.post('/filter', getCategoriesByFilter);

export default router;